"""
Navix Rubika Bot Framework
A powerful, modern, and high-performance framework for Rubika bots.
"""

from .client import Client
from .router import Router
from .dispatcher import Dispatcher
from .fsm import MemoryStorage, SQLiteStorage
from .types import Message
from .keyboard import InlineKeyboardBuilder
from .filters import Command, Text
from .scheduler import BackgroundScheduler
from .i18n import I18n
from .paginator import Paginator
from .plugins import PluginManager
from .broadcast import Broadcaster
from .webhook import WebhookServer
from .throttling import Throttler
from .config import Config
from .ecosystem import (
    MultiBotManager,
    SecurityGuard,
    BackupManager,
    PaymentHandler,
    HealthMonitor,
    retry
)
from .doctor import run_doctor
from .debugger import profile_handler, inspect_packet
from .metrics import metrics, MetricsCollector
from .middleware import MiddlewareManager
from .log import setup_logger, logger
from .exceptions import (
    NavixError,
    NetworkError,
    AuthError,
    ValidationError,
    FSMError
)

__version__ = "1.0.0"
__all__ = [
    "Client",
    "Router",
    "Dispatcher",
    "MemoryStorage",
    "SQLiteStorage",
    "Message",
    "InlineKeyboardBuilder",
    "Command",
    "Text",
    "BackgroundScheduler",
    "I18n",
    "Paginator",
    "PluginManager",
    "Broadcaster",
    "WebhookServer",
    "Throttler",
    "Config",
    "MultiBotManager",
    "SecurityGuard",
    "BackupManager",
    "PaymentHandler",
    "HealthMonitor",
    "retry",
    "run_doctor",
    "profile_handler",
    "inspect_packet",
    "metrics",
    "MetricsCollector",
    "MiddlewareManager",
    "setup_logger",
    "logger",
    "NavixError",
    "NetworkError",
    "AuthError",
    "ValidationError",
    "FSMError"
]
