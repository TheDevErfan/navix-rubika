"""
Advanced Event Router for Navix with Filter Support
"""
import asyncio
from typing import Callable, List, Any
from .log import logger
from .types import Message

class Router:
    """
    سیستم روتر پیشرفته با پشتیبانی کامل از فیلترهای سفارشی
    """
    def __init__(self):
        self.message_handlers: List[tuple] = []
        logger.debug("روتر پیشرفته جدید ایجاد شد.")

    def message(self, *filters: Any):
        """
        دکوراتور ثبت هندلر همراه با فیلترهای دلخواه (مثل Command یا Text)
        """
        def decorator(func: Callable):
            self.message_handlers.append((func, filters))
            logger.debug(f"هندلر جدید ثبت شد: {func.__name__} با {len(filters)} فیلتر.")
            return func
        return decorator

    async def feed_update(self, update: dict, client=None):
        logger.debug("پردازش آپدیت جدید در روتر...")
        msg = Message(update, client=client)
        
        for handler, filters in self.message_handlers:
            try:
                # ارزیابی فیلترها
                passed = True
                for f in filters:
                    if callable(f):
                        if asyncio.iscoroutinefunction(f):
                            res = await f(msg)
                        else:
                            res = f(msg)
                        if not res:
                            passed = False
                            break
                
                if passed:
                    if asyncio.iscoroutinefunction(handler):
                        await handler(msg)
                    else:
                        handler(msg)
                    break # پس از اولین تطابق متوقف می‌شود
            except Exception as e:
                logger.error(f"خطا در اجرای هندلر {handler.__name__}: {e}", exc_info=True)
